(function($) {
  "use strict";
  
  AOS.init();
  
  // Preloader
  $(window).on('load', function() {
    if ($('#preloader').length) {
      $('#preloader').delay(100).fadeOut('slow', function() {
        $(this).remove();
      });
    }
  });

$('.datepicker').datepicker({
    autoclose: true,
	format: 'yyyy-mm-dd',
	endDate: '+0d',
});

$("#thumbs-scroll").mCustomScrollbar({
	theme:"dark-thin",
	scrollButtons:{enable:true},
});

$('.top-search').on('click', function(){
    $('.top-search-open').toggleClass('show');
	$(this).toggleClass('text-red');
});


$('.search-close').on('click', function(){
    $('.top-search-open').removeClass('show');
	$('.top-search').removeClass('text-red');
});


$('.product-carousel').owlCarousel({
    loop:true,
    margin:10,
    dots:true,
    nav:true,
    mouseDrag:true,
    autoplay:true,
	smartSpeed: 3000, 
    autoplayTimeout:4000,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:2
        },
        1200:{
            items:3
        }
    }
});

$('.product-details-carousel').owlCarousel({
    loop:true,
    margin:30,
    dots:true,
    nav:true,
    mouseDrag:true,
    autoplay:true,
	smartSpeed: 3000, 
    autoplayTimeout:4000,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        },
        1200:{
            items:4
        }
    }
});


$('.testimonial_owlCarousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
    nav:true,
    autoplay:false,   
    smartSpeed: 3000, 
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})


$('.team-carousel').owlCarousel({
    loop:true,
    margin:20,
    dots:true,
    nav:true,
    mouseDrag:true,
    autoplay:true,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        },
        1200:{
            items:4
        }
    }
});

$('.awards-carousel').owlCarousel({
    loop:true,
    margin:20,
    dots:true,
    nav:true,
    mouseDrag:true,
    autoplay:true,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:2
        },
        1200:{
            items:2
        }
    }
});


$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".navbar").addClass("fixed");
    } else {
        $(".navbar").removeClass("fixed");
    }
});


$('.navbar-nav .nav-link').hover(function() {
    $(this).trigger('click');
}, function() { });


$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 300) {
        $(".back-to-top").addClass("scrollfixed");
    } else {
        $(".back-to-top").removeClass("scrollfixed");
    }
});


$('.back-to-top').click(function() {
    $('html, body').animate({
      scrollTop: 0
    }, 500);
    return false;
  });

$("#subForm").validate();

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 1200) {
        $(".navigation").addClass("fixed");
    } else {
        $(".navigation").removeClass("fixed");
    }
});

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 800) {
        $(".product-details-colors").addClass("fixed-bottom");
    } else {
        $(".product-details-colors").removeClass("fixed-bottom");
    }
});

	
$("#country, #city, #state, #filters, #state_ship, #stateee, #menucategory, #menucategory, #category, #product").select2({
     allowClear: false
});


document.querySelector(".card-flip").classList.toggle("flip");

})(jQuery);