1. Unzip the the folder import to superstorefinder root directory of the installation
2. Populate sample_data.csv with the data that you wish to import
3. Run http://yourserver.com/storefinderfolder/import/import.php 4. All data within that CSV will be automatically imported into the database.
4. The script will auto detect coordinate from the address.