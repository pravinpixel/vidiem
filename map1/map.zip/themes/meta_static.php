	<link rel="stylesheet" type="text/css" href="<?php echo ROOT_URL; ?>css/superstorefinder.css" media="all" />
	<link rel="stylesheet" type="text/css" href="<?php echo ROOT_URL; ?>css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="<?php echo ROOT_URL; ?>css/bootstrap-responsive.css" media="all" />
	
	<script src="https://j.maxmind.com/app/geoip.js" type="text/javascript"><!--mce:1--></script>
	<script src="https://maps.googleapis.com/maps/api/js?sensor=false&libraries=geometry,places"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/jquery-1.9.0.min.js"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/bootstrap.js"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/super-store-finder-demo.js" charset="utf-8"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/jquery.sort.js" charset="utf-8"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/jquery.geocomplete.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo ROOT_URL; ?>css/typography.css" media="all" />
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />