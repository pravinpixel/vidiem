﻿<footer class="footer">
  <div class="container">
	<p><a href="https://superstorefinder.net/products/superstorefinder">Super Store Finder</a> is designed and built by Joe Iz from <a href="https://highwardenhuntsman.blogspot.com">Highwarden Huntsman</a>.</p>
	<p>Code licensed under <a href="https://codecanyon.net/licenses/regular_extended" target="_blank">Regular & Extended License</a>. Purchasable exclusively only at <a href="https://codecanyon.net/item/super-store-finder/3630922" target="new">Codecanyon</a></p>

	<ul class="footer-links">
	  
	</ul>
  </div>
</footer>