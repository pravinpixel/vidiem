<?php

include_once "./includes/config.inc.php";

logout();