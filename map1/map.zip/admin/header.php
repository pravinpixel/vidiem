	<link rel="stylesheet" type="text/css" href="<?php echo ROOT_URL; ?>css/style.css" media="all" />
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="../css/bootstrap-responsive.css" media="all" />
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/jquery-1.9.0.min.js"></script>
	<script type="text/javascript" src="<?php echo ROOT_URL; ?>js/super-store-finder.js"></script>
	<script type="text/javascript" src="../js/bootstrap.js"></script>
